# TangZX81 — ZX81 core for Tang Console 138K

**Status: integrated RTL and Gowin project flow prepared, but not yet validated
with Gowin EDA or on hardware.** Peripheral simulations, top-level loader/reset
simulation, and Verilator elaboration pass. The Verilator CPU is only a stub:
these checks do **not** run Z80 instructions, validate tape loading against a
real ZX81 ROM, or prove BRAM/PLL/timing fit on the FPGA.

## Fixed design requirements

- Target: Sipeed Tang Console 138K (`GW5AST-LV138PG484AC1/I0`), loaded from
  microSD.
- CPU: T80 Z80-compatible core, clocked from the nominal 52 MHz PLL output;
  CPU and ULA enables are 3.25 MHz and 6.5 MHz. BL616/UART remains on the
  board's actual 50 MHz input (`iosys_bl616 FREQ=50_000_000`). The PLL wrapper
  has not yet been compiled in Gowin.
- Main RAM: fixed 16 KiB at `0x4000–0x7fff`, always enabled. The user-supplied
  8 KiB OS ROM is loaded into a separate dual-clock buffer from SD; it is not
  embedded in this repository or added to synthesis.
- Raw ZX81 `.P` files are streamed to a separate tape buffer and played through
  the normal EAR/tape-input path at original speed; there is no direct RAM
  injection or turbo loader. The player starts on the ROM's `LOAD` entry fetch
  (`0x0347`) after a tape is ready. The FPGA releases the machine once a valid
  ROM is present even if no tape is buffered; the current firmware patch loads
  the ROM alongside a selected `.P` file.
- Cassette timing is modelled as a 5 s leader, nominal 150 µs half-pulses,
  4 pulses for a zero / 9 for a one, and 1.3 ms between bits. Typical data
  averages close to 300 bit/s. Raw `.P` files omit a filename, so the player
  proposes a synthetic empty-name terminator (`0x80`); this still requires
  validation against a real ROM and hardware.
- Keyboard bytes arrive as PS/2 Set-2 scancodes from BL616 firmware.
  `src/zx81/zx81_keyboard_matrix.sv` is a TangZX81 implementation; the MiSTer
  keyboard module is deliberately not copied because its header restricts use
  to non-commercial purposes.
- With no OS ROM loaded the machine is held in reset. To bring up the BL616
  firmware menu/OSD, use **SELECT + D-pad RIGHT**; do not substitute a shoulder
  button for RIGHT.
- The project is intended to remain distributable under GPL-3.0. See
  [`ATTRIBUTION.md`](ATTRIBUTION.md), including the outstanding license review
  for the inherited DS2 controller source.

## Build on Windows with Gowin

Use Gowin EDA Standard V1.9.12.04. From this directory run:

```bat
buildall.bat
```

The script locates `gw_sh`, records the package/toolchain/version information
and complete transcript in `build.log`, then runs `build.tcl`. The intended
bitstream path is `impl\pnr\zx81_tang_console138k.bin` (also emits `.fs`).
The `.cst` retains the Tang Console 138K port names; `src/boards/tangzx81.sdc`
constrains the 50 MHz input, PLL outputs, and 74.25 MHz pixel clock.

**This Gowin flow has not been run in the Linux agent environment.** Please
send `build.log` if Gowin reports an error; no claim of successful Gowin
synthesis, timing closure, or hardware operation is made yet. `usb_hid_host.v`
reads `usb_hid_host_rom.hex` relative to the project/build root, so keep that
file next to `build.tcl` when building.

## Verilator checks

With Verilator and a C++ compiler installed:

```sh
make -C sim test VERILATOR=verilator
make -C sim lint lint-machine lint-video lint-top lint-board VERILATOR=verilator
```

`test` runs the peripheral testbench and a top-level loading/reset test. The
latter checks that an incomplete ROM keeps the machine reset, a complete ROM
releases it even without a tape, a later tape transfer gates/restarts the
machine, and active-low `s1` resets it. `lint-machine`, `lint-video`, and
`lint-top` elaborate the corresponding RTL. A simulation-only `T80pa` stub is
used because Verilator does not compile the Gowin mixed-language VHDL CPU; the
stub is not a functional CPU model. `lint-board` also elaborates the top's
production preprocessor branch with stand-ins for Gowin primitives and IOSys;
it compiles the actual USB-HID and DS2 RTL but is not a Gowin synthesis check.
A few legacy `hdl-util/hdmi` warning classes are suppressed only for video/top
lint targets.

## BL616 SD/firmware integration

The stock May 2025 BL616 firmware has file loaders for core IDs 1–6. TangZX81
uses unknown ID **8** (not a reused firmware ID); an unknown ID is safe for
bitstream programming but does not by itself add SD file loading. The separate
firmware patch adds the ZX81 menu entry, streams the user's ROM as loading-state
1 and the selected `.P` as loading-state 2, using the existing BL616 `0x06`
loading-state and `0x07` data commands.

Patch: [`firmware/firmware-bl616-zx81.patch`](firmware/firmware-bl616-zx81.patch).
It is intended for `nand2mario/firmware-bl616` at the May 2025 base (`a5a6ea1`);
apply and build it in that firmware checkout, then update the Console 138K
BL616 firmware. This patch has not been built against the Bouffalo SDK.

Intended SD layout:

```text
cores/zx81tang.bin             # bitstream (or cores/console138k/zx81tang.bin)
zx81/rom/zx81.rom              # user-supplied, exactly 8192 bytes
zx81/*.P                       # raw ZX81 programs, up to 16384 bytes
```

No ROM image is included. Users must provide ROMs and programs they are
entitled to use.

## Current RTL and project files

- `src/zx81/zx81_machine.sv` — T80 wrapper, 16 KiB RAM, ROM/tape bus, keyboard,
  ULA/video raster, and normal tape-input integration.
- `src/zx81/zx81_sd_loader.sv` — ROM/tape dual-clock stream buffers and ready,
  length, and overflow status.
- `src/zx81/zx81_tape_player.sv` — original-speed `.P` waveform generator.
- `src/zx81/zx81_keyboard_matrix.sv` — Set-2 scancodes/controller inputs to
  the active-low 8×5 ZX81 keyboard matrix.
- `src/hdmi2/zx81_video_hdmi.sv` — ping-pong source capture, provisional
  328×246 frame window, nearest-neighbour 720p60 scaler, OSD input, and HDMI
  output. The capture crop/window and display geometry still need comparison
  against the reference core and a monitor.
- `src/zx81_tang_top.sv` — Tang Console top, PLLs, `iosys_bl616`, loader,
  controls, HDMI, and disabled SDRAM pins.
- `build.tcl`, `buildall.bat`, and `src/boards/tangzx81.sdc` — Gowin project,
  Windows runner, and timing constraints.
- `src/zx81/T80/` — T80 VHDL sources.
- `sim/` — peripheral and top reset/load testbenches. The top test does not
  execute CPU instructions because it uses the `T80pa` lint/simulation stub.

The MiSTer `.mif`, ROM, MiSTer platform top, and turbo tape-loader patch are
intentionally absent.

## References

- [MiSTer ZX81 core](https://github.com/MiSTer-devel/ZX81_MiSTer) — machine and
  T80 integration reference; the MiSTer top, ROM image, and accelerated loader
  are not reused.
- [ZX81 specifications and cassette format](https://www.problemkaputt.de/zxdocs.htm)
- [ZX80/ZX81 `.P` and `.P81` format notes](https://k1.spdns.de/Develop/Projects/zasm/Info/O80%20and%20P81%20Format.txt)

See [`ATTRIBUTION.md`](ATTRIBUTION.md) for source and license notes.
