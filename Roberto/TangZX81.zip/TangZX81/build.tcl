# TangZX81 FPGA build for Sipeed Tang Console 138K.
# Run from this directory: gw_sh build.tcl (or buildall.bat on Windows).
set_device GW5AST-LV138PG484AC1/I0 -device_version B

add_file -type verilog "src/zx81_tang_top.sv"
add_file -type verilog "src/zx81/zx81_machine.sv"
add_file -type verilog "src/zx81/zx81_sd_loader.sv"
add_file -type verilog "src/zx81/zx81_tape_player.sv"
add_file -type verilog "src/zx81/zx81_keyboard_matrix.sv"
add_file -type verilog "src/hdmi2/zx81_video_hdmi.sv"
add_file -type cst "src/boards/console138k.cst"
add_file -type sdc "src/boards/tangzx81.sdc"

# TangPong board infrastructure: 50 MHz BL616/UART, USB/DS2, 52 MHz machine,
# and 720p60 HDMI clock chain.
add_file -type verilog "src/pll/gowin_pll_52.v"
add_file -type verilog "src/pll/gowin_pll_27.v"
add_file -type verilog "src/pll/gowin_pll_hdmi.v"
add_file -type verilog "src/pll/pll_12_14m.v"
add_file -type verilog "src/ctrl/usb_hid_host.v"
add_file -type verilog "src/ctrl/controller_ds2.sv"
add_file -type verilog "src/ctrl/dualshock_controller.v"

# T80 VHDL dependencies must precede the wrappers that instantiate them.
add_file -type vhdl "src/zx81/T80/T80_ALU.vhd"
add_file -type vhdl "src/zx81/T80/T80_MCode.vhd"
add_file -type vhdl "src/zx81/T80/T80_Reg.vhd"
add_file -type vhdl "src/zx81/T80/T80.vhd"
add_file -type vhdl "src/zx81/T80/T80pa.vhd"

# BL616 OSD/UART and HDMI core from TangPong / hdl-util/hdmi.
add_file -type verilog "src/iosys/iosys_bl616.v"
add_file -type verilog "src/iosys/gowin_dpb_menu.v"
add_file -type verilog "src/iosys/textdisp.v"
add_file -type verilog "src/iosys/uart_fixed.v"
add_file -type verilog "src/hdmi2/audio_clock_regeneration_packet.sv"
add_file -type verilog "src/hdmi2/audio_info_frame.sv"
add_file -type verilog "src/hdmi2/audio_sample_packet.sv"
add_file -type verilog "src/hdmi2/auxiliary_video_information_info_frame.sv"
add_file -type verilog "src/hdmi2/hdmi.sv"
add_file -type verilog "src/hdmi2/packet_assembler.sv"
add_file -type verilog "src/hdmi2/packet_picker.sv"
add_file -type verilog "src/hdmi2/serializer.sv"
add_file -type verilog "src/hdmi2/source_product_description_info_frame.sv"
add_file -type verilog "src/hdmi2/tmds_channel.sv"

# usb_hid_host_rom.hex is loaded by $readmemh from the project/build root.
# The ZX81 OS ROM is never a synthesis input: BL616 streams the user's 8 KiB
# image into zx81_sd_loader at run time.
set_option -output_base_name zx81_tang_console138k
set_option -synthesis_tool gowinsynthesis
set_option -top_module zx81_tang_top
set_option -verilog_std sysv2017
set_option -rw_check_on_ram 1
set_option -use_mspi_as_gpio 1
set_option -use_ready_as_gpio 1
set_option -use_done_as_gpio 1
set_option -use_i2c_as_gpio 1
set_option -use_cpu_as_gpio 1
set_option -use_sspi_as_gpio 1
set_option -multi_boot 1
set_option -place_option 2

run all
