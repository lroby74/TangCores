# BL616 firmware patch

`firmware-bl616-zx81.patch` targets the public
[`nand2mario/firmware-bl616`](https://github.com/nand2mario/firmware-bl616)
repository at commit `a5a6ea1` (2025-05-03).

From the firmware repository root:

```sh
git apply --check /path/to/TangCores/TangZX81/firmware/firmware-bl616-zx81.patch
git apply /path/to/TangCores/TangZX81/firmware/firmware-bl616-zx81.patch
```

It adds Console 138K core ID 8 and an SD loader for `.P` files. The loader
expects an 8 KiB user-supplied OS ROM at `zx81/rom/zx81.rom` and the selected
`.P` file under `zx81/`. It sends ROM bytes with `loading_state=1`, tape bytes
with `loading_state=2`, then returns to state 0. The FPGA ingress must use
those exact state values.

The BL616 firmware source is Apache-2.0. This patch has only been checked for
clean application against the pinned source snapshot; the Bouffalo SDK build
and on-device firmware update remain unverified.
