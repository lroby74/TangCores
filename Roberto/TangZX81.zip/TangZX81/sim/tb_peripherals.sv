// SPDX-License-Identifier: GPL-3.0-only
`timescale 1ns / 1ps

module tb_peripherals;
    logic clk = 1'b0;
    always #10 clk = ~clk;

    logic resetn = 1'b0;
    logic [7:0] loading_state = 8'd0;
    logic [7:0] data_in = 8'd0;
    logic data_valid = 1'b0;
    logic [12:0] rom_read_address = 13'd0;
    logic [7:0] rom_read_data;
    logic [13:0] tape_read_address;
    logic [7:0] tape_read_data;
    logic rom_ready;
    logic tape_ready;
    logic [14:0] tape_length;
    logic overflow;

    zx81_sd_loader loader (
        .clk_write(clk), .clk_core(clk), .resetn(resetn),
        .loading_state(loading_state), .data_in(data_in), .data_valid(data_valid),
        .rom_read_address(rom_read_address), .rom_read_data(rom_read_data),
        .tape_read_address(tape_read_address), .tape_read_data(tape_read_data),
        .rom_ready(rom_ready), .tape_ready(tape_ready),
        .tape_length(tape_length), .overflow(overflow)
    );

    logic [7:0] kbd_data = 8'd0;
    logic kbd_data_valid = 1'b0;
    logic [15:0] addr = 16'hFFFF;
    logic [11:0] joy = 12'd0;
    logic [4:0] key_data;

    zx81_keyboard_matrix keyboard (
        .clk(clk), .resetn(resetn),
        .kbd_data(kbd_data), .kbd_data_valid(kbd_data_valid),
        .addr(addr), .joy(joy), .key_data(key_data)
    );

    logic tape_start = 1'b0;
    logic [14:0] player_length = 15'd1;
    logic [7:0] player_data = 8'h00;
    logic [13:0] player_address;
    logic tape_in;
    logic tape_busy;
    logic tape_done;
    integer tape_rises = 0;
    integer high_width_cycles = 0;
    integer bad_high_widths = 0;
    integer low_width_cycles = 0;
    integer measured_bit_gaps = 0;
    integer bad_bit_gaps = 0;
    logic measuring_low = 1'b0;
    logic previous_tape_in = 1'b0;

    // Scaled pulse parameters keep this unit test short. Production defaults
    // are in 52 MHz cycles and model the documented cassette timings.
    zx81_tape_player #(
        .PULSE_HALF_CYCLES(2), .BIT_GAP_CYCLES(2),
        .LEADER_CYCLES(2), .READ_LATENCY(1)
    ) tape_player (
        .clk(clk), .resetn(resetn), .start(tape_start),
        .tape_length(player_length), .tape_read_data(player_data),
        .tape_read_address(player_address), .tape_in(tape_in),
        .busy(tape_busy), .done(tape_done)
    );

    always @(posedge clk) begin
        if (!resetn) begin
            previous_tape_in   <= 1'b0;
            tape_rises         <= 0;
            high_width_cycles  <= 0;
            bad_high_widths    <= 0;
            low_width_cycles   <= 0;
            measured_bit_gaps  <= 0;
            bad_bit_gaps       <= 0;
            measuring_low      <= 1'b0;
        end else begin
            if (tape_in && !previous_tape_in) begin
                tape_rises <= tape_rises + 1;
                if (measuring_low && low_width_cycles > 2) begin
                    measured_bit_gaps <= measured_bit_gaps + 1;
                    if (low_width_cycles < 5)
                        bad_bit_gaps <= bad_bit_gaps + 1;
                end
                measuring_low     <= 1'b0;
                high_width_cycles <= 1;
            end else if (tape_in) begin
                high_width_cycles <= high_width_cycles + 1;
            end

            if (!tape_in && previous_tape_in) begin
                if (high_width_cycles != 2)
                    bad_high_widths <= bad_high_widths + 1;
                low_width_cycles <= 1;
                measuring_low    <= 1'b1;
            end else if (!tape_in && measuring_low) begin
                low_width_cycles <= low_width_cycles + 1;
            end
            previous_tape_in <= tape_in;
        end
    end

    task automatic tick;
        begin
            @(posedge clk);
            #1;
        end
    endtask

    task automatic send_scan(input logic [7:0] scan);
        begin
            @(negedge clk);
            kbd_data = scan;
            kbd_data_valid = 1'b1;
            tick();
            @(negedge clk);
            kbd_data_valid = 1'b0;
            tick();
        end
    endtask

    integer i;
    integer timeout_cycles;
    initial begin
        repeat (4) tick();
        resetn = 1'b1;
        tick();

        // Load a full 8 KiB ROM stream, then a four-byte .P payload.
        loading_state = 8'd1;
        data_valid = 1'b1;
        for (i = 0; i < 8192; i = i + 1) begin
            data_in = i[7:0];
            tick();
        end
        data_valid = 1'b0;
        loading_state = 8'd2;
        tick();
        repeat (2) tick(); // ready crosses from the 50 MHz loader domain
        if (!rom_ready) $fatal(1, "ROM-ready was not asserted at the stage change");

        data_valid = 1'b1;
        data_in = 8'hA5; tick();
        data_in = 8'h5A; tick();
        data_in = 8'h00; tick();
        data_in = 8'hFF; tick();
        data_valid = 1'b0;
        loading_state = 8'd0;
        tick();
        repeat (2) tick(); // tape-ready and length cross into the core domain
        if (!tape_ready || tape_length != 4)
            $fatal(1, "tape stream length/ready mismatch: ready=%0d len=%0d", tape_ready, tape_length);
        if (overflow) $fatal(1, "unexpected stream overflow");

        rom_read_address = 13'h0012;
        tick();
        if (rom_read_data !== 8'h12) $fatal(1, "ROM RAM readback mismatch");
        tape_read_address = 14'd1;
        tick();
        if (tape_read_data !== 8'h5A) $fatal(1, "tape RAM readback mismatch");

        // The A key is row 1 / column 0; make and break must be reflected
        // on the active-low ULA matrix.
        addr = 16'hFDFF;
        send_scan(8'h1C);             // A make
        if (key_data !== 5'b11110) $fatal(1, "A key matrix make mismatch: %b", key_data);
        send_scan(8'hF0);             // break prefix
        send_scan(8'h1C);             // A break
        if (key_data !== 5'b11111) $fatal(1, "A key matrix break mismatch: %b", key_data);

        // Cursor-up and controller-up both produce CAPS SHIFT + 7.
        addr = 16'hEEFF;              // select rows 0 and 4
        send_scan(8'hE0);
        send_scan(8'h75);             // extended Up make
        if (key_data !== 5'b10110) $fatal(1, "keyboard cursor-up mapping mismatch: %b", key_data);
        send_scan(8'hE0);
        send_scan(8'hF0);
        send_scan(8'h75);             // extended Up break
        joy[7] = 1'b1;                // TangCore pad bit 7 = UP
        #1;
        if (key_data !== 5'b10110) $fatal(1, "controller-up mapping mismatch: %b", key_data);
        joy[7] = 1'b0;
        joy[4] = 1'b1;                // bit 4 = RIGHT -> CAPS SHIFT + 8
        #1;
        if (key_data !== 5'b11010) $fatal(1, "controller-right mapping mismatch: %b", key_data);
        joy[4] = 1'b0;
        addr = 16'hF6FF;              // select rows 0 and 3; key 5 is row 3
        joy[5] = 1'b1;                // bit 5 = LEFT -> CAPS SHIFT + 5
        #1;
        if (key_data !== 5'b01110) $fatal(1, "controller-left mapping mismatch: %b", key_data);
        joy[5] = 1'b0;
        addr = 16'hEEFF;              // select rows 0 and 4; key 6 is row 4
        joy[6] = 1'b1;                // bit 6 = DOWN -> CAPS SHIFT + 6
        #1;
        if (key_data !== 5'b01110) $fatal(1, "controller-down mapping mismatch: %b", key_data);
        joy[6] = 1'b0;

        // Backspace is CAPS SHIFT + 0, so selecting only row 0 must see shift.
        addr = 16'hFEFF;
        send_scan(8'h66);
        if (key_data !== 5'b11110) $fatal(1, "backspace CAPS SHIFT mapping mismatch: %b", key_data);
        send_scan(8'hF0);
        send_scan(8'h66);
        if (key_data !== 5'b11111) $fatal(1, "backspace break mismatch: %b", key_data);

        // Controller B is also a convenient ENTER key.
        addr = 16'hBFFF;              // select row 6
        joy[11] = 1'b1;
        #1;
        if (key_data !== 5'b11110) $fatal(1, "controller-enter mapping mismatch: %b", key_data);
        joy[11] = 1'b0;

        // A one-byte zero payload follows the synthesized 0x80 empty-name
        // marker: 9 + 7*4 + 8*4 = 69 rising cassette pulses.
        tape_rises = 0;
        tape_start = 1'b1;
        tick();
        tape_start = 1'b0;
        timeout_cycles = 0;
        while (!tape_done && timeout_cycles < 2000) begin
            tick();
            timeout_cycles = timeout_cycles + 1;
        end
        if (!tape_done) $fatal(1, "tape playback timed out");
        if (tape_rises != 69)
            $fatal(1, "tape pulse count mismatch: got %0d, expected 69", tape_rises);
        if (bad_high_widths != 0)
            $fatal(1, "cassette high-pulse width mismatch: %0d bad pulses", bad_high_widths);
        if (measured_bit_gaps == 0 || bad_bit_gaps != 0)
            $fatal(1, "cassette inter-bit gap missing/too short: gaps=%0d bad=%0d",
                   measured_bit_gaps, bad_bit_gaps);

        $display("TangZX81 peripherals: PASS");
        $finish;
    end
endmodule
