# Verilator checks

Run from the TangZX81 directory with Verilator 5.x and a C++ compiler:

```sh
make -C sim test VERILATOR=verilator
make -C sim lint lint-machine lint-video lint-top lint-board VERILATOR=verilator
```

`test` runs two testbenches:

- `tb_peripherals.sv` verifies 8 KiB ROM and `.P` stream loading/readback,
  stage transitions, Set-2 make/break handling, ZX81 keyboard-matrix rows,
  controller input, and cassette pulse counts/widths/gaps. Tape timing values
  are scaled down only in the testbench. The proposed `0x80` empty-name marker
  is not validated against a real ZX81 ROM.
- `tb_top_reset.sv` instantiates the TangZX81 top with simulation clocks and
  verifies incomplete-ROM reset gating, boot with a complete ROM and no tape,
  reset while a later tape transfer is in progress, and active-low `s1` reset.
  It does not execute CPU instructions or inspect tape contents through a
  running ROM.

`lint-machine`, `lint-video`, and `lint-top` elaborate the simulation branch of
the newly integrated RTL. `lint-board` undefines `VERILATOR` to elaborate the
production top branch with test stand-ins for Gowin PLL/IO/serializer and IOSys
blocks; it includes the actual USB-HID and DS2 RTL. These stand-ins are not
synthesis sources. `sim/t80pa_stub.sv` replaces the VHDL `T80pa` entity for
Verilator only; it returns idle bus values and is not a functional CPU. The
video/top lint commands suppress a few legacy width/comb warnings from the
inherited `hdl-util/hdmi` sources, not from the ZX81 machine logic.

This is not a full ZX81 CPU/video simulation. Gowin EDA, mixed-language VHDL
synthesis, BRAM inference, board timing, and hardware have not been validated
in this environment.
