`timescale 1ns/1ps
`default_nettype none

module tb_top_reset;
    logic clk_main = 1'b0;
    logic clk_core = 1'b0;
    logic clk12 = 1'b0;
    logic clk_pixel = 1'b0;
    logic clk_5x_pixel = 1'b0;
    logic resetn = 1'b0;
    logic s1 = 1'b1;
    logic [7:0] loading_state = 8'd0;
    logic [7:0] data = 8'd0;
    logic data_valid = 1'b0;

    wire [23:0] rgb;
    wire [10:0] cx;
    wire [9:0] cy;
    wire active;
    wire core_resetn;
    wire tape_busy;
    wire uart_tx;
    wire [7:0] led;
    wire ds_clk, ds_mosi, ds_cs, ds_clk2, ds_mosi2, ds_cs2;
    wire tmds_clk_n, tmds_clk_p;
    wire [2:0] tmds_d_n, tmds_d_p;
    wire sdram_clk, sdram_cs_n, sdram_cas_n, sdram_ras_n, sdram_wen_n;
    wire [12:0] sdram_addr;
    wire [1:0] sdram_ba, sdram_dqm;
    tri [15:0] sdram_dq;
    tri usb1_dp, usb1_dn, usb2_dp, usb2_dn;

    always #10.000 clk_main = ~clk_main;       // 50 MHz
    always #9.615 clk_core = ~clk_core;       // 52 MHz nominal
    always #41.667 clk12 = ~clk12;            // 12 MHz
    always #6.734 clk_pixel = ~clk_pixel;      // 74.25 MHz nominal
    always #1.347 clk_5x_pixel = ~clk_5x_pixel;// 371.25 MHz nominal

    zx81_tang_top dut (
        .sys_clk(1'b0), .s1(s1), .UART_RXD(1'b1), .UART_TXD(uart_tx),
        .O_sdram_clk(sdram_clk), .O_sdram_cs_n(sdram_cs_n),
        .O_sdram_cas_n(sdram_cas_n), .O_sdram_ras_n(sdram_ras_n),
        .O_sdram_wen_n(sdram_wen_n), .IO_sdram_dq(sdram_dq),
        .O_sdram_addr(sdram_addr), .O_sdram_ba(sdram_ba),
        .O_sdram_dqm(sdram_dqm), .led(led),
        .ds_clk(ds_clk), .ds_miso(1'b0), .ds_mosi(ds_mosi), .ds_cs(ds_cs),
        .ds_clk2(ds_clk2), .ds_miso2(1'b0), .ds_mosi2(ds_mosi2), .ds_cs2(ds_cs2),
        .usb1_dp(usb1_dp), .usb1_dn(usb1_dn), .usb2_dp(usb2_dp), .usb2_dn(usb2_dn),
        .tmds_clk_n(tmds_clk_n), .tmds_clk_p(tmds_clk_p),
        .tmds_d_n(tmds_d_n), .tmds_d_p(tmds_d_p),
        .sim_clk_main(clk_main), .sim_clk_core(clk_core), .sim_clk12(clk12),
        .sim_clk_pixel(clk_pixel), .sim_clk_5x_pixel(clk_5x_pixel),
        .sim_resetn(resetn), .sim_joy_usb1(12'd0), .sim_joy_usb2(12'd0),
        .sim_hid1(16'd0), .sim_hid2(16'd0), .sim_overlay(1'b0),
        .sim_overlay_color(15'd0), .sim_core_config(32'd0),
        .sim_loading_state(loading_state), .sim_data(data),
        .sim_data_valid(data_valid), .sim_kbd_data(8'd0), .sim_kbd_valid(1'b0),
        .sim_rgb(rgb), .sim_cx(cx), .sim_cy(cy), .sim_active(active),
        .sim_core_resetn(core_resetn), .sim_tape_busy(tape_busy)
    );

    task automatic send_bytes(input integer count, input logic [7:0] seed);
        integer n;
        begin
            for (n = 0; n < count; n = n + 1) begin
                @(negedge clk_main);
                data = seed + 8'(n);
                data_valid = 1'b1;
            end
            @(negedge clk_main);
            data_valid = 1'b0;
        end
    endtask

    initial begin
        repeat (4) @(negedge clk_main);
        resetn = 1'b1;

        // An incomplete ROM must not release the machine.
        @(negedge clk_main);
        loading_state = 8'd1;
        send_bytes(16, 8'h20);
        @(negedge clk_main);
        loading_state = 8'd0;
        repeat (6) @(posedge clk_core);
        if (core_resetn !== 1'b0)
            $fatal(1, "machine reset released with an incomplete ROM");

        // A fresh, complete ROM stream is sufficient to boot BASIC without a
        // selected tape file.
        @(negedge clk_main);
        loading_state = 8'd1;
        send_bytes(8192, 8'h00);
        @(negedge clk_main);
        loading_state = 8'd0;
        wait (core_resetn === 1'b1);
        $display("PASS: complete ROM releases the machine without requiring a tape");

        // A later tape load temporarily resets the machine, then resumes it.
        @(negedge clk_main);
        loading_state = 8'd2;
        repeat (5) @(posedge clk_core);
        if (core_resetn !== 1'b0)
            $fatal(1, "machine did not stay reset while a tape file was loading");
        send_bytes(4, 8'h80);
        @(negedge clk_main);
        loading_state = 8'd0;
        wait (core_resetn === 1'b1);
        $display("PASS: a later tape transfer pauses and resumes the machine");

        s1 = 1'b0;
        repeat (5) @(posedge clk_core);
        if (core_resetn !== 1'b0)
            $fatal(1, "active-low s1 did not reset the machine");
        s1 = 1'b1;
        repeat (5) @(posedge clk_core);
        if (core_resetn !== 1'b1)
            $fatal(1, "machine did not restart after releasing s1");

        $display("PASS: s1 restarts the CPU without clearing the SD buffers");
        $finish;
    end

    initial begin
        #500000;
        $fatal(1, "timeout waiting for loader/reset test to complete");
    end
endmodule

`default_nettype wire
