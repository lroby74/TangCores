// SPDX-License-Identifier: GPL-3.0-only
// Simulation placeholder for the VHDL T80pa entity. It is used for RTL
// elaboration/lint, not for CPU functional simulation.
`default_nettype none
module T80pa #(
    parameter integer Mode = 0
) (
    input  logic        RESET_n,
    input  logic        CLK,
    input  logic        CEN_p,
    input  logic        CEN_n,
    input  logic        WAIT_n,
    input  logic        INT_n,
    input  logic        NMI_n,
    input  logic        BUSRQ_n,
    output logic        M1_n,
    output logic        MREQ_n,
    output logic        IORQ_n,
    output logic        RD_n,
    output logic        WR_n,
    output logic        RFSH_n,
    output logic        HALT_n,
    output logic        BUSAK_n,
    input  logic        OUT0,
    output logic [15:0] A,
    input  logic [7:0]  DI,
    output logic [7:0]  DO,
    output logic [211:0] REG,
    input  logic        DIRSet,
    input  logic [211:0] DIR
);
    always_comb begin
        M1_n = 1'b1;
        MREQ_n = 1'b1;
        IORQ_n = 1'b1;
        RD_n = 1'b1;
        WR_n = 1'b1;
        RFSH_n = 1'b1;
        HALT_n = 1'b1;
        BUSAK_n = 1'b1;
        A = 16'd0;
        DO = 8'd0;
        REG = 212'd0;
    end
endmodule
`default_nettype wire
