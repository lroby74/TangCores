// SPDX-License-Identifier: GPL-3.0-only
// Elaboration-only stand-ins for board-specific modules in the production top.
// This file is used by Verilator's lint-board target and is never synthesized.
`default_nettype none

module gowin_pll_52 (
    output logic lock,
    output logic clkout0,
    output logic clkout1,
    input  logic clkin
);
    assign lock = 1'b1;
    assign clkout0 = clkin;
    assign clkout1 = clkin;
endmodule

module pll_12_14m (
    output logic lock,
    output logic clkout0,
    output logic clkout1,
    input  logic clkin
);
    assign lock = 1'b1;
    assign clkout0 = clkin;
    assign clkout1 = clkin;
endmodule

module gowin_pll_27 (
    input  logic clkin,
    output logic clkout0
);
    assign clkout0 = clkin;
endmodule

module gowin_pll_hdmi (
    input  logic clkin,
    output logic clkout
);
    assign clkout = clkin;
endmodule

module CLKDIV #(
    parameter integer DIV_MODE = 5
) (
    output logic CLKOUT,
    input  logic HCLKIN,
    input  logic RESETN,
    input  logic CALIB
);
    assign CLKOUT = HCLKIN;
endmodule

module OSER10 (
    output logic Q,
    input  logic D0, D1, D2, D3, D4, D5, D6, D7, D8, D9,
    input  logic PCLK,
    input  logic FCLK,
    input  logic RESET
);
    assign Q = 1'b0;
endmodule

module ELVDS_OBUF (
    input  logic I,
    output logic O,
    output logic OB
);
    assign O = I;
    assign OB = ~I;
endmodule

module iosys_bl616 #(
    parameter integer FREQ = 21_477_000,
    parameter logic [14:0] COLOR_LOGO = 15'b00000_10101_00000,
    parameter logic [15:0] CORE_ID = 16'd1,
    parameter logic [7:0] LOADING_STATE = 8'd0
) (
    input  logic clk,
    input  logic hclk,
    input  logic resetn,
    output logic overlay,
    input  logic [7:0] overlay_x,
    input  logic [7:0] overlay_y,
    output logic [14:0] overlay_color,
    input  logic [11:0] joy1,
    input  logic [11:0] joy2,
    output logic [15:0] hid1,
    output logic [15:0] hid2,
    output logic [7:0] rom_loading,
    output logic [7:0] rom_do,
    output logic rom_do_valid,
    output logic [15:0] mgmt_address,
    output logic mgmt_read,
    input  logic [15:0] mgmt_readdata,
    output logic mgmt_write,
    output logic [15:0] mgmt_writedata,
    input  logic [1:0] fdd_request,
    output logic [7:0] kbd_data,
    output logic kbd_data_valid,
    output logic [31:0] core_config,
    input  logic uart_rx,
    output logic uart_tx
);
    assign overlay = 1'b0;
    assign overlay_color = 15'd0;
    assign hid1 = 16'd0;
    assign hid2 = 16'd0;
    assign rom_loading = LOADING_STATE;
    assign rom_do = 8'd0;
    assign rom_do_valid = 1'b0;
    assign mgmt_address = 16'd0;
    assign mgmt_read = 1'b0;
    assign mgmt_write = 1'b0;
    assign mgmt_writedata = 16'd0;
    assign kbd_data = 8'd0;
    assign kbd_data_valid = 1'b0;
    assign core_config = 32'd0;
    assign uart_tx = 1'b1;
endmodule

module gowin_dpb_menu (
    output logic [7:0] douta,
    output logic [7:0] doutb,
    input  logic clka,
    input  logic ocea,
    input  logic cea,
    input  logic reseta,
    input  logic wrea,
    input  logic clkb,
    input  logic oceb,
    input  logic ceb,
    input  logic resetb,
    input  logic wreb,
    input  logic [10:0] ada,
    input  logic [7:0] dina,
    input  logic [10:0] adb,
    input  logic [7:0] dinb
);
    assign douta = 8'd0;
    assign doutb = 8'd0;
endmodule

`default_nettype wire
