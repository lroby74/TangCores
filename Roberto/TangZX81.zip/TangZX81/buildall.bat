@echo off
setlocal
rem TangZX81 bitstream build for Tang Console 138K.
rem Finds gw_sh from PATH, GOWIN_HOME, or common Gowin installation folders.

cd /d "%~dp0"
echo Build directory: %CD%
if exist "VERSION" (
    set /p TANGZX81_REV=<VERSION
) else (
    set TANGZX81_REV=unknown-old-package
)
echo TangZX81 package revision: %TANGZX81_REV%
if not exist "build.tcl" (
    echo ERROR: build.tcl not found in %CD%.
    echo Unzip the package so buildall.bat and build.tcl are in the same folder.
    pause
    exit /b 1
)

set "GWSH="
rem Gowin EDA Standard V1.9.12.04 is the supported local toolchain.
if exist "C:\Gowin\Gowin_V1.9.12.04_x64\IDE\bin\gw_sh.exe" set "GWSH=C:\Gowin\Gowin_V1.9.12.04_x64\IDE\bin\gw_sh.exe"
where gw_sh >nul 2>&1
if %errorlevel% equ 0 (
    for /f "delims=" %%i in ('where gw_sh') do set "GWSH=%%i"
)
if not defined GWSH if defined GOWIN_HOME (
    if exist "%GOWIN_HOME%\IDE\bin\gw_sh.exe" set "GWSH=%GOWIN_HOME%\IDE\bin\gw_sh.exe"
)
if not defined GWSH (
    for /d %%d in ("C:\Gowin\Gowin_*" "D:\Gowin\Gowin_*") do (
        if exist "%%d\IDE\bin\gw_sh.exe" set "GWSH=%%d\IDE\bin\gw_sh.exe"
    )
)
if not defined GWSH (
    echo ERROR: gw_sh not found. Install Gowin EDA Standard, then either
    echo   - add its IDE\bin to PATH, or
    echo   - set GOWIN_HOME, or
    echo   - install under C:\Gowin.
    pause
    exit /b 1
)

echo Using %GWSH%
echo Supported toolchain: Gowin EDA Standard V1.9.12.04
echo.
echo Running Gowin build; the flow writes its full transcript to build.log.
(
    echo TangZX81 package revision: %TANGZX81_REV%
    echo Supported Gowin toolchain: Standard V1.9.12.04
    echo Executable: %GWSH%
    echo Started: %DATE% %TIME%
) > build.log
"%GWSH%" build.tcl >> build.log 2>&1
set BUILD_ERR=%errorlevel%
if %BUILD_ERR% neq 0 (
    echo.
    echo BUILD FAILED with error %BUILD_ERR%.
    echo.
    echo ============ ERROR lines from build.log ============
    findstr /n /I "ERROR" build.log
    echo ====================================================
    echo Full transcript: %CD%\build.log
    pause
    exit /b %BUILD_ERR%
)

if not exist "impl\pnr\zx81_tang_console138k.bin" (
    echo BUILD FAILED: Gowin returned success but the expected .bin is missing.
    echo ============ ERROR lines from build.log ============
    findstr /n /I "ERROR" build.log
    echo ====================================================
    echo Full transcript: %CD%\build.log
    pause
    exit /b 1
)
dir impl\pnr\zx81_tang_console138k.bin impl\pnr\zx81_tang_console138k.fs
echo.
echo Done. Copy impl\pnr\zx81_tang_console138k.bin to microSD as cores\zx81tang.bin.
echo Reminder: BL616 firmware support for core ID 8 and SD file loading is separate.
echo The user-provided ZX81 OS ROM must be installed on SD; no ROM is bundled.
pause
