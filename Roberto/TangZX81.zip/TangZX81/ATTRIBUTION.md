# Attribution and license notes

TangZX81 is a work in progress. Review these notes before redistributing a
bitstream or source package, especially the DS2 controller-license issue below.

## TangCore platform templates

The BL616 UART/OSD files, USB-HID host, Gowin PLL wrappers, board constraints,
and build-flow starting points are adapted from
[nand2mario/nestang](https://github.com/nand2mario/nestang), via the working
`TangPong/` template in this repository. Their license and copyright notices
are retained; these platform sources are GPL-3.0. The HDMI transmitter in
`src/hdmi2/` is [hdl-util/hdmi](https://github.com/hdl-util/hdmi), licensed
under Apache-2.0 and used as in NESTang. TangZX81 follows the repository's
GPL-3.0 license.

`src/iosys/iosys_bl616.v` has one TangZX81 interface correction: the BL616
`kbd_data` byte is an output of the IOSys block, not an input.

The `controller_ds2.sv` / `dualshock_controller.v` path is inherited from the
TangPong template. `TangPong/ATTRIBUTION.md` records a non-commercial-use
restriction for `dualshock_controller.v`. That restriction is **not resolved**
by this project: obtain separate permission or replace the dependency with a
suitably licensed implementation before treating the complete source package
as cleared for commercial use or unrestricted redistribution.

## ZX81 CPU and machine reference

- `src/zx81/T80/` is the T80 Z80-compatible CPU by Daniel Wallner and
  contributors, including the Sorgelig changes present in the MiSTer ZX81
  source. The upstream source carries its BSD-style redistribution and
  non-endorsement conditions in each VHDL file; those headers are preserved.
- `src/zx81/zx81_machine.sv` adapts machine/ULA bus and video-timing behavior
  from [MiSTer-devel/ZX81_MiSTer](https://github.com/MiSTer-devel/ZX81_MiSTer),
  snapshot `9b24af6` (2026-06-03). The upstream machine logic is GPL-2.0-or-later,
  compatible with this GPL-3.0 project; its source/copyright reference is also
  recorded in the RTL header. The MiSTer platform top, ROM image, and
  accelerated tape-loader code are not reused.
- `src/zx81/ym2149.sv` is the YM2149 implementation by MikeJ and Sorgelig,
  copied from MiSTer ZX81. Its upstream BSD-style notice is preserved. It is
  not instantiated in the current ZX81 machine (which has no PSG).

## TangZX81 RTL

`src/zx81/zx81_sd_loader.sv`, `src/zx81/zx81_tape_player.sv`, and
`src/zx81/zx81_keyboard_matrix.sv` are written for this project.
`src/hdmi2/zx81_video_hdmi.sv` and `src/zx81_tang_top.sv` are TangZX81
integration RTL around the attributed TangCore HDMI/platform sources. The
Verilator-only `sim/t80pa_stub.sv` is a non-functional CPU placeholder for
elaboration and top-level loader/reset tests; it is not used in the Gowin build.

The original MiSTer `rtl/keyboard.sv` is **not** included: its header grants
non-commercial use only, which is not being combined with the GPL-3.0 core.
No Sinclair ZX81/TS1000 ROM, `rtl/zx8x.mif`, ROM dump, or `.P` program is
included. Users must obtain and supply ROM images and programs they are
entitled to use.

## Firmware patch

`firmware/firmware-bl616-zx81.patch` is intended for
[nand2mario/firmware-bl616](https://github.com/nand2mario/firmware-bl616),
which is Apache-2.0 licensed. The patch is supplied separately for the user
to apply/build in that firmware repository; it does not change this FPGA
repository's license.

## Cassette-format references

The tape timing and `.P`-file handling are based on publicly documented
ZX81 cassette signals and file layout linked from the core README. These are
format facts, not copied RTL.
