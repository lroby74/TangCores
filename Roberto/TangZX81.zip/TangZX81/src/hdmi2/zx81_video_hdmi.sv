// SPDX-License-Identifier: GPL-3.0-only
// ZX81 framebuffer/scaler and HDMI output, based on TangPong's HDMI pipeline.
`timescale 1ns / 1ps
`default_nettype none

module zx81_video_hdmi (
    input  logic        clk_core,        // 52 MHz ZX81 domain
    input  logic        resetn,
    input  logic        ce_pixel,        // 6.5 MHz source-pixel enable
    input  logic        hblank,
    input  logic        vblank,
    input  logic        video_pixel,

    input  logic        overlay,
    input  logic [14:0] overlay_color,   // BGR5 from BL616 OSD
    output logic [7:0]  overlay_x,
    output logic [7:0]  overlay_y,

    input  logic        clk_pixel,       // 74.25 MHz
    input  logic        clk_5x_pixel,    // 371.25 MHz
    output logic        tmds_clk_n,
    output logic        tmds_clk_p,
    output logic [2:0]  tmds_d_n,
    output logic [2:0]  tmds_d_p
`ifdef VERILATOR
    ,output logic [23:0] sim_rgb,
    output logic [10:0] sim_cx,
    output logic [9:0]  sim_cy,
    output logic        sim_active
`endif
);

    localparam integer VIDEO_ID = 4;        // 720p60
    localparam integer VIDEO_REFRESH = 60;
    localparam integer CLKFRQ_KHZ = 74250;
    localparam integer AUDIO_RATE = 48000;
    localparam integer AUDIO_BIT_WIDTH = 16;
    localparam integer FRAME_WIDTH = 328;   // hblank timing: 72..399
    localparam integer FRAME_HEIGHT = 246;  // provisional 4:3 source frame
    localparam integer FRAME_DEPTH = FRAME_WIDTH * FRAME_HEIGHT;
    localparam logic [8:0] FRAME_WIDTH_9 = 9'd328;
    localparam logic [8:0] FRAME_HEIGHT_9 = 9'd246;
    localparam logic [10:0] ACTIVE_WIDTH_11 = 11'd960;
    localparam logic [9:0] ACTIVE_HEIGHT_10 = 10'd720;

    // Ping-pong frame buffers: the display reads a completed source frame
    // while the capture domain fills the other bank.
    logic frame_mem0 [0:FRAME_DEPTH-1];
    logic frame_mem1 [0:FRAME_DEPTH-1];
    logic capture_bank;
    logic display_bank_core;
    logic display_bank_meta;
    logic display_bank_sync;
    logic display_bank_pixel;
    logic [8:0] capture_x;
    logic [8:0] capture_y;
    logic hblank_d;
    logic vblank_d;
    logic frame_valid;
    wire [16:0] capture_y_ext = {8'd0, capture_y};
    wire [16:0] capture_x_ext = {8'd0, capture_x};
    wire [16:0] capture_addr = (capture_y_ext << 8) +
                               (capture_y_ext << 6) +
                               (capture_y_ext << 3) + capture_x_ext;

    // Capture one source frame from the ZX81's 6.5 MHz raster. The machine
    // generates hblank/vblank in the same clock domain as this write port.
    always_ff @(posedge clk_core or negedge resetn) begin
        if (!resetn) begin
            capture_bank <= 1'b0;
            display_bank_core <= 1'b1;
            capture_x <= 9'd0;
            capture_y <= 9'd0;
            hblank_d <= 1'b1;
            vblank_d <= 1'b1;
            frame_valid <= 1'b0;
        end else if (ce_pixel) begin
            hblank_d <= hblank;
            vblank_d <= vblank;

            if (vblank && !vblank_d) begin
                capture_x <= 9'd0;
                capture_y <= 9'd0;
                display_bank_core <= capture_bank;
                capture_bank <= ~capture_bank;
                frame_valid <= 1'b1;
            end else if (!vblank) begin
                if (!hblank) begin
                    if (capture_x < FRAME_WIDTH_9 && capture_y < FRAME_HEIGHT_9) begin
                        if (capture_bank)
                            frame_mem1[capture_addr] <= video_pixel;
                        else
                            frame_mem0[capture_addr] <= video_pixel;
                    end
                    if (capture_x < FRAME_WIDTH_9)
                        capture_x <= capture_x + 1'b1;
                end
                if (hblank && !hblank_d) begin
                    capture_x <= 9'd0;
                    if (capture_y < FRAME_HEIGHT_9)
                        capture_y <= capture_y + 1'b1;
                end
            end
        end
    end

    logic frame_valid_meta;
    logic frame_valid_pixel;
    always_ff @(posedge clk_pixel or negedge resetn) begin
        if (!resetn) begin
            frame_valid_meta <= 1'b0;
            frame_valid_pixel <= 1'b0;
            display_bank_meta <= 1'b1;
            display_bank_sync <= 1'b1;
            display_bank_pixel <= 1'b1;
        end else begin
            frame_valid_meta <= frame_valid;
            frame_valid_pixel <= frame_valid_meta;
            display_bank_meta <= display_bank_core;
            display_bank_sync <= display_bank_meta;
            if (cy == 10'd0)
                display_bank_pixel <= display_bank_sync;
        end
    end

    logic [8:0] source_x;
    logic [8:0] source_y;
    logic [9:0] x_accum;
    logic [9:0] y_accum;
    logic [9:0] cy_d;
    logic active;
    logic frame_pixel0_q;
    logic frame_pixel1_q;
    logic [23:0] rgb;
    wire [10:0] cx;
    wire [9:0] cy;
    wire frame_pixel_q = display_bank_pixel ? frame_pixel1_q : frame_pixel0_q;
    wire [16:0] source_y_ext = {8'd0, source_y};
    wire [16:0] source_x_ext = {8'd0, source_x};
    wire [16:0] source_addr = (source_y_ext << 8) +
                              (source_y_ext << 6) +
                              (source_y_ext << 3) + source_x_ext;

    always_ff @(posedge clk_pixel) begin
        frame_pixel0_q <= frame_mem0[source_addr];
        frame_pixel1_q <= frame_mem1[source_addr];
    end

    assign overlay_x = (source_x < 9'd256) ? source_x[7:0] : 8'hFF;
    assign overlay_y = (source_y < 9'd256) ? source_y[7:0] : 8'hFF;

    // Fractional nearest-neighbour scaler: 328x246 to 960x720, centered
    // in the 1280x720 HDMI active area. The exact crop/visible window remains
    // an item for comparison with the user's ZX81 ROM and monitor.
    always_ff @(posedge clk_pixel or negedge resetn) begin : display_scaler
        logic active_now;
        logic [10:0] x_next;
        logic [10:0] y_next;
        if (!resetn) begin
            source_x <= 9'd0;
            source_y <= 9'd0;
            x_accum <= 10'd0;
            y_accum <= 10'd0;
            cy_d <= 10'd0;
            active <= 1'b0;
            rgb <= 24'h000000;
        end else begin
            active_now = 1'b0;
            if (cx == 11'd159) begin
                active_now = 1'b1;
                active <= 1'b1;
            end else if (cx == 11'd1119) begin
                active_now = 1'b0;
                active <= 1'b0;
            end

            if (active_now || active) begin
                x_next = {1'b0, x_accum} + {2'b00, FRAME_WIDTH_9};
                if (x_next >= ACTIVE_WIDTH_11) begin
                    x_accum <= 10'(x_next - ACTIVE_WIDTH_11);
                    if (source_x < 9'd327)
                        source_x <= source_x + 1'b1;
                end else begin
                    x_accum <= x_next[9:0];
                end
            end

            cy_d <= cy;
            if (cy[0] != cy_d[0]) begin
                y_next = {1'b0, y_accum} + {2'b00, FRAME_HEIGHT_9};
                if (y_next >= {1'b0, ACTIVE_HEIGHT_10}) begin
                    y_accum <= 10'(y_next - {1'b0, ACTIVE_HEIGHT_10});
                    if (source_y < 9'd245)
                        source_y <= source_y + 1'b1;
                end else begin
                    y_accum <= y_next[9:0];
                end
            end

            if (cx == 0) begin
                source_x <= 9'd0;
                x_accum <= 10'd0;
            end
            if (cy == 0) begin
                source_y <= 9'd0;
                y_accum <= 10'd0;
            end

            if (active) begin
                if (overlay)
                    rgb <= {overlay_color[4:0], 3'b0,
                            overlay_color[9:5], 3'b0,
                            overlay_color[14:10], 3'b0};
                else if (frame_valid_pixel)
                    rgb <= frame_pixel_q ? 24'hFFFFFF : 24'h000000;
                else
                    rgb <= 24'h000000;
            end else begin
                rgb <= 24'h303030;
            end
        end
    end

    localparam integer AUDIO_CLK_DELAY = CLKFRQ_KHZ * 1000 / AUDIO_RATE / 2;
    localparam logic [9:0] AUDIO_DIV_END = 10'(AUDIO_CLK_DELAY - 1);
    logic [$clog2(AUDIO_CLK_DELAY)-1:0] audio_divider;
    logic clk_audio;
    logic [15:0] audio_sample_word [0:1];
    always_ff @(posedge clk_pixel or negedge resetn) begin
        if (!resetn) begin
            audio_divider <= '0;
            clk_audio <= 1'b0;
            audio_sample_word[0] <= 16'd0;
            audio_sample_word[1] <= 16'd0;
        end else if (audio_divider == AUDIO_DIV_END) begin
            audio_divider <= '0;
            clk_audio <= ~clk_audio;
        end else begin
            audio_divider <= audio_divider + 1'b1;
            audio_sample_word[0] <= 16'd0;
            audio_sample_word[1] <= 16'd0;
        end
    end

    logic [2:0] tmds;
    logic tmds_clock;
    logic [10:0] frame_width;
    logic [9:0] frame_height;
    logic [10:0] screen_width;
    logic [9:0] screen_height;

    hdmi #(
        .VIDEO_ID_CODE(VIDEO_ID),
        .DVI_OUTPUT(0),
        .VIDEO_REFRESH_RATE(VIDEO_REFRESH),
        .IT_CONTENT(1),
        .AUDIO_RATE(AUDIO_RATE),
        .AUDIO_BIT_WIDTH(AUDIO_BIT_WIDTH),
        .VENDOR_NAME("TangCore"),
        .PRODUCT_DESCRIPTION({"TangZX81", 64'd0}),
        .START_X(0),
        .START_Y(0)
    ) hdmi_inst (
        .clk_pixel_x5(clk_5x_pixel),
        .clk_pixel(clk_pixel),
        .clk_audio(clk_audio),
        .rgb(rgb),
        .reset(~resetn),
        .audio_sample_word(audio_sample_word),
        .tmds(tmds),
        .tmds_clock(tmds_clock),
        .cx(cx),
        .cy(cy),
        .frame_width(frame_width),
        .frame_height(frame_height),
        .screen_width(screen_width),
        .screen_height(screen_height)
    );

`ifndef VERILATOR
    ELVDS_OBUF tmds_bufds [3:0] (
        .I({clk_pixel, tmds}),
        .O({tmds_clk_p, tmds_d_p}),
        .OB({tmds_clk_n, tmds_d_n})
    );
`else
    assign {tmds_clk_p, tmds_d_p} = 4'b0;
    assign {tmds_clk_n, tmds_d_n} = 4'b0;
    assign sim_rgb = rgb;
    assign sim_cx = cx;
    assign sim_cy = cy;
    assign sim_active = active;
`endif

endmodule

`default_nettype wire
