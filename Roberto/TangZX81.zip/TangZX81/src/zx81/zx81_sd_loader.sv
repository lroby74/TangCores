// SPDX-License-Identifier: GPL-3.0-only
// TangZX81 SD stream ingress.
// Loading-state protocol carried by iosys_bl616:
//   0: idle/run, 1: 8 KiB ZX81 ROM stream, 2: .P tape-data stream.
// No ROM image is initialized from a repository file.
`default_nettype none

module zx81_sd_loader #(
    parameter integer ROM_BYTES  = 8192,
    parameter integer TAPE_BYTES = 16384
) (
    input  wire logic        clk_write,  // 50 MHz BL616/UART domain
    input  wire logic        clk_core,   // ZX81 machine domain (52 MHz)
    input  wire logic        resetn,
    input  wire logic [7:0]  loading_state,
    input  wire logic [7:0]  data_in,
    input  wire logic        data_valid,

    input  wire logic [12:0] rom_read_address,
    output logic [7:0]  rom_read_data,
    input  wire logic [13:0] tape_read_address,
    output logic [7:0]  tape_read_data,

    output logic        rom_ready,   // synchronized into clk_core
    output logic        tape_ready,  // synchronized into clk_core
    output logic [14:0] tape_length,// captured after tape_ready is synchronized
    output logic        overflow     // synchronized into clk_core
);

    localparam [7:0] LOAD_IDLE = 8'd0;
    localparam [7:0] LOAD_ROM  = 8'd1;
    localparam [7:0] LOAD_TAPE = 8'd2;
    localparam integer ROM_ADDR_WIDTH = 13;
    localparam integer TAPE_ADDR_WIDTH = 14;

    // These arrays are true dual-clock RAMs: SD writes use clk_write and the
    // machine gets registered reads on clk_core. They are intentionally not
    // reset/initialized, so Gowin can infer block RAM rather than reset FFs.
    logic [7:0] rom_mem  [0:ROM_BYTES-1];
    logic [7:0] tape_mem [0:TAPE_BYTES-1];

    logic [7:0] previous_state;
    logic [14:0] rom_count;
    logic [14:0] tape_count;
    logic [14:0] tape_length_write;
    logic rom_ready_write;
    logic tape_ready_write;
    logic overflow_write;
    logic rom_ready_meta;
    logic tape_ready_meta;
    logic overflow_meta;

    always_ff @(posedge clk_write) begin
        if (loading_state == LOAD_ROM && data_valid && rom_count < 15'(ROM_BYTES))
            rom_mem[rom_count[ROM_ADDR_WIDTH-1:0]] <= data_in;
        if (loading_state == LOAD_TAPE && data_valid && tape_count < 15'(TAPE_BYTES))
            tape_mem[tape_count[TAPE_ADDR_WIDTH-1:0]] <= data_in;
    end

    always_ff @(posedge clk_core) begin
        rom_read_data  <= rom_mem[rom_read_address];
        tape_read_data <= tape_mem[tape_read_address];
    end

    always_ff @(posedge clk_write or negedge resetn) begin
        if (!resetn) begin
            previous_state  <= LOAD_IDLE;
            rom_count       <= 15'd0;
            tape_count      <= 15'd0;
            tape_length_write <= 15'd0;
            rom_ready_write <= 1'b0;
            tape_ready_write <= 1'b0;
            overflow_write  <= 1'b0;
        end else begin
            if (loading_state != previous_state) begin
                case (loading_state)
                    LOAD_ROM: begin
                        rom_count        <= 15'd0;
                        rom_ready_write  <= 1'b0;
                        tape_count       <= 15'd0;
                        tape_length_write <= 15'd0;
                        tape_ready_write <= 1'b0;
                        overflow_write   <= 1'b0;
                    end
                    LOAD_TAPE: begin
                        if (previous_state == LOAD_ROM)
                            rom_ready_write <= (rom_count == 15'(ROM_BYTES));
                        tape_count       <= 15'd0;
                        tape_length_write <= 15'd0;
                        tape_ready_write <= 1'b0;
                    end
                    LOAD_IDLE: begin
                        if (previous_state == LOAD_ROM)
                            rom_ready_write <= (rom_count == 15'(ROM_BYTES));
                        if (previous_state == LOAD_TAPE) begin
                            tape_length_write <= tape_count;
                            tape_ready_write   <= (tape_count != 0);
                        end
                    end
                    default: ;
                endcase
                previous_state <= loading_state;
            end

            if (data_valid) begin
                case (loading_state)
                    LOAD_ROM: begin
                        if (rom_count < 15'(ROM_BYTES))
                            rom_count <= rom_count + 1'b1;
                        else
                            overflow_write <= 1'b1;
                    end
                    LOAD_TAPE: begin
                        if (tape_count < 15'(TAPE_BYTES))
                            tape_count <= tape_count + 1'b1;
                        else
                            overflow_write <= 1'b1;
                    end
                    default: ;
                endcase
            end
        end
    end

    // Ready and length are stable after each stream finishes. Synchronize the
    // flags into the machine domain; capture the multi-bit length only after
    // the synchronized ready flag has crossed.
    always_ff @(posedge clk_core or negedge resetn) begin
        if (!resetn) begin
            rom_ready_meta  <= 1'b0;
            tape_ready_meta <= 1'b0;
            overflow_meta   <= 1'b0;
            rom_ready       <= 1'b0;
            tape_ready      <= 1'b0;
            overflow        <= 1'b0;
            tape_length     <= 15'd0;
        end else begin
            rom_ready_meta  <= rom_ready_write;
            tape_ready_meta <= tape_ready_write;
            overflow_meta   <= overflow_write;
            rom_ready       <= rom_ready_meta;
            tape_ready      <= tape_ready_meta;
            overflow        <= overflow_meta;
            if (tape_ready_meta)
                tape_length <= tape_length_write;
            else
                tape_length <= 15'd0;
        end
    end

endmodule

`default_nettype wire
