// SPDX-License-Identifier: GPL-3.0-only
//
// ZX81 machine/ULA logic adapted from the MiSTer ZX81 core.
// Copyright (C) 2018 Gyorgy Szombathelyi
// MiSTer port logic Copyright (C) 2018, 2019 Sorgelig
// Upstream reference: MiSTer-devel/ZX81_MiSTer, snapshot 9b24af6.
// CPU/video timing and refresh-address behavior follow that reference;
// MiSTer system glue, ROM image and accelerated tape-loader patch do not.
// The upstream GPL-2.0-or-later source is compatible with this GPL-3.0-only
// project. T80 retains its separate BSD-style notices in src/zx81/T80/.
`default_nettype none

module zx81_machine (
    input  wire logic        clk,              // 52 MHz machine clock
    input  wire logic        resetn,
    input  wire logic [11:0] joy,              // TangCore DS2/SNES layout
    input  wire logic [31:0] core_config,
    input  wire logic [7:0]  kbd_data,         // BL616 PS/2 Set-2 byte
    input  wire logic        kbd_data_valid,

    input  wire logic [7:0]  rom_data,
    output logic [12:0] rom_address,
    input  wire logic [7:0]  tape_data,
    output logic [13:0] tape_address,
    input  wire logic [14:0] tape_length,
    input  wire logic        tape_ready,
    output logic        tape_busy,
    output logic        tape_done,

    output logic        ce_pixel,         // 6.5 MHz pixel enable
    output logic        hblank,
    output logic        vblank,
    output logic        video_pixel
);

    logic [4:0] ce_divider;
    logic ce_cpu_p;
    logic ce_cpu_n;
    logic ce_cpu_3m25;
    logic ce_6m5;

    logic [15:0] cpu_address;
    logic [7:0] cpu_dout;
    logic [7:0] cpu_din;
    logic m1_n;
    logic mreq_n;
    logic iorq_n;
    logic rd_n;
    logic wr_n;
    logic rfsh_n;
    logic halt_n;
    logic busak_n;

    logic hsync;
    logic nmi_latch;
    logic [7:0] sync_counter;
    wire nmi_n = ~nmi_latch | ~hsync;
    wire wait_n = ~halt_n | nmi_n;

    logic [7:0] ram_data_latch;
    logic [2:0] row_counter;
    logic [7:0] ram_mem [0:16383];
    logic [7:0] ram_q;
    logic [7:0] memory_data;

    logic [4:0] key_data;
    logic [7:0] kbd_data_meta;
    logic kbd_valid_meta;
    logic [7:0] kbd_data_core;
    logic kbd_valid_core;
    logic tape_in;

    logic vs;
    logic vsync;
    logic [7:0] shifter_reg;
    logic inverse;
    logic nopgen_store;
    logic shifter_en;
    logic old_shifter_start;
    logic old_hsync_video;
    logic old_hblank;
    logic [8:0] raster_counter;
    logic [4:0] vreg;
    logic old_hsync_raster;

    logic [7:0] core_config_meta;
    logic [7:0] core_config_core;
    logic [11:0] joy_meta;
    logic [11:0] joy_core;
    logic old_m1_n;
    logic tape_start;

    wire [13:0] ram_address = cpu_address[13:0];
    wire rom_select = ~cpu_address[15] & ~cpu_address[14] & ~cpu_address[13];
    wire ram_select = (cpu_address[15:14] == 2'b01); // fixed 16 KiB at $4000-$7FFF
    wire refresh_increment = cpu_address[13] & ram_data_latch[7] & cpu_address[8];
    wire [3:0] refresh_high = cpu_address[12:9] + {3'b000, refresh_increment};
    wire keyboard_read = ~iorq_n & ~rd_n & ~cpu_address[0];
    wire [7:0] io_data = keyboard_read ? {tape_in, 1'b1, 1'b0, key_data} : 8'hFF;
    wire nopgen = cpu_address[15] & ~memory_data[6] & halt_n;
    wire data_latch_enable = rfsh_n & ce_cpu_p & ~mreq_n;
    wire shifter_start = mreq_n & nopgen_store & ce_cpu_p & shifter_en & ~nmi_latch;
    wire video_inverse = core_config_core[0];

    // Clock-enable pattern from the behavioral ZX81 reference: 3.25 MHz CPU,
    // 6.5 MHz video, both derived from the 52 MHz machine clock.
    always_ff @(negedge clk or negedge resetn) begin
        if (!resetn) begin
            ce_divider  <= 5'd0;
            ce_cpu_p    <= 1'b0;
            ce_cpu_n    <= 1'b0;
            ce_cpu_3m25 <= 1'b0;
            ce_6m5      <= 1'b0;
        end else begin
            ce_divider  <= ce_divider + 1'b1;
            ce_cpu_p    <= (ce_divider[3:0] == 4'b0000);
            ce_cpu_n    <= ce_divider[3] & (ce_divider[2:0] == 3'b000);
            ce_cpu_3m25 <= (ce_divider[3:0] == 4'b0000);
            ce_6m5      <= (ce_divider[2:0] == 3'b000);
        end
    end
    assign ce_pixel = ce_6m5;

    // T80 is VHDL and is compiled by Gowin. Verilator unit tests use a small
    // T80pa stub; no claim of CPU instruction-level simulation is made here.
    T80pa #(.Mode(0)) cpu (
        .RESET_n(resetn),
        .CLK(clk),
        .CEN_p(ce_cpu_p),
        .CEN_n(ce_cpu_n),
        .WAIT_n(wait_n),
        .INT_n(cpu_address[6]),
        .NMI_n(nmi_n),
        .BUSRQ_n(1'b1),
        .M1_n(m1_n),
        .MREQ_n(mreq_n),
        .IORQ_n(iorq_n),
        .RD_n(rd_n),
        .WR_n(wr_n),
        .RFSH_n(rfsh_n),
        .HALT_n(halt_n),
        .BUSAK_n(busak_n),
        .OUT0(1'b0),
        .A(cpu_address),
        .DI(cpu_din),
        .DO(cpu_dout),
        .REG(),
        .DIRSet(1'b0),
        .DIR(212'b0)
    );

    // Synchronous 16 KiB main RAM. The OS ROM remains an SD-loaded buffer.
    always_ff @(posedge clk) begin
        if (!mreq_n && !wr_n && ram_select)
            ram_mem[ram_address] <= cpu_dout;
        ram_q <= ram_mem[ram_address];
    end

    always_comb begin
        if (rfsh_n)
            rom_address = cpu_address[12:0];
        else
            rom_address = {refresh_high, ram_data_latch[5:0], row_counter};

        if (rom_select)
            memory_data = rom_data;
        else if (ram_select)
            memory_data = ram_q;
        else
            memory_data = 8'hFF;

        if (!mreq_n && !rd_n)
            cpu_din = (!m1_n && nopgen) ? 8'h00 : memory_data;
        else if (!iorq_n && !rd_n)
            cpu_din = io_data;
        else
            cpu_din = 8'hFF;
    end

    // Synchronize the bundled BL616 scancode and its valid pulse into clk.
    // A UART command holds the byte stable across the two destination stages.
    always_ff @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            kbd_data_meta <= 8'd0;
            kbd_valid_meta <= 1'b0;
            kbd_data_core <= 8'd0;
            kbd_valid_core <= 1'b0;
        end else begin
            kbd_data_meta <= kbd_data;
            kbd_valid_meta <= kbd_data_valid;
            kbd_data_core <= kbd_data_meta;
            kbd_valid_core <= kbd_valid_meta;
        end
    end

    zx81_keyboard_matrix keyboard (
        .clk(clk),
        .resetn(resetn),
        .kbd_data(kbd_data_core),
        .kbd_data_valid(kbd_valid_core),
        .addr(cpu_address),
        .joy(joy_core),
        .key_data(key_data)
    );

    // ZX81 ULA interrupt, NMI and sync-control I/O writes.
    always_ff @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            hsync <= 1'b0;
            nmi_latch <= 1'b0;
            sync_counter <= 8'd0;
            vs <= 1'b0;
            vsync <= 1'b0;
        end else begin
            if (ce_cpu_3m25) begin
                if (sync_counter == 8'd206)
                    sync_counter <= 8'd0;
                else
                    sync_counter <= sync_counter + 1'b1;
                if (sync_counter == 8'd15)
                    hsync <= 1'b1;
                if (sync_counter == 8'd31)
                    hsync <= 1'b0;
            end

            if (!m1_n && !iorq_n) begin
                sync_counter <= 8'd0;
                hsync <= 1'b0;
            end

            if (!iorq_n && !wr_n && (cpu_address[0] ^ cpu_address[1]))
                nmi_latch <= cpu_address[1];

            if (!iorq_n && !wr_n && !nmi_latch)
                vs <= 1'b0;
            if (keyboard_read && !nmi_latch)
                vs <= 1'b1;
            if (!hsync)
                vsync <= vs;
        end
    end

    // Refresh-address video shifter and blanking waveforms from the ZX81 ULA.
    always_ff @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            ram_data_latch <= 8'd0;
            row_counter <= 3'd0;
            shifter_reg <= 8'd0;
            inverse <= 1'b0;
            nopgen_store <= 1'b0;
            shifter_en <= 1'b0;
            old_shifter_start <= 1'b0;
            old_hsync_video <= 1'b0;
            old_hblank <= 1'b1;
        end else if (ce_6m5) begin
            old_hsync_video <= hsync;
            if (data_latch_enable) begin
                ram_data_latch <= memory_data;
                nopgen_store <= nopgen;
            end
            if (mreq_n && ce_cpu_p)
                inverse <= 1'b0;

            old_shifter_start <= shifter_start;
            shifter_reg <= {shifter_reg[6:0], 1'b0};
            if (!old_shifter_start && shifter_start) begin
                shifter_reg <= (!m1_n && nopgen) ? 8'h00 : memory_data;
                inverse <= ram_data_latch[7];
            end

            if (!old_hsync_video && hsync)
                row_counter <= row_counter + 1'b1;
            if (vs)
                row_counter <= 3'd0;

            old_hblank <= hblank;
            if (!old_hblank && hblank)
                shifter_en <= 1'b0;
            if (old_hblank && !hblank)
                shifter_en <= ~nmi_latch;
        end
    end

    always_ff @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            raster_counter <= 9'd0;
            vreg <= 5'd0;
            old_hsync_raster <= 1'b0;
            hblank <= 1'b1;
            vblank <= 1'b1;
        end else if (ce_6m5) begin
            raster_counter <= raster_counter + 1'b1;
            if (raster_counter == 9'd413)
                raster_counter <= 9'd0;

            if (raster_counter == 9'd400)
                hblank <= 1'b1;
            if (raster_counter == 9'd72)
                hblank <= 1'b0;

            old_hsync_raster <= hsync;
            if (!old_hsync_raster && hsync) begin
                vreg <= {vreg[3:0], vsync};
                vblank <= |{vreg, vsync};
                if (&vreg[3:2])
                    raster_counter <= 9'd0;
            end
        end
    end

    // Synchronize slowly changing controller/configuration inputs into clk.
    always_ff @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            core_config_meta <= 8'd0;
            core_config_core <= 8'd0;
            joy_meta <= 12'd0;
            joy_core <= 12'd0;
        end else begin
            core_config_meta <= core_config[7:0];
            core_config_core <= core_config_meta;
            joy_meta <= joy;
            joy_core <= joy_meta;
        end
    end
    assign video_pixel = ~video_inverse ^ shifter_reg[7] ^ inverse;

    // Start normal cassette playback at the ROM's LOAD entry point. No ROM
    // patching or direct writes to the CPU RAM occur here.
    always_ff @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            old_m1_n <= 1'b1;
            tape_start <= 1'b0;
        end else begin
            old_m1_n <= m1_n;
            tape_start <= 1'b0;
            if (tape_ready && old_m1_n && !m1_n && cpu_address == 16'h0347)
                tape_start <= 1'b1;
        end
    end

    zx81_tape_player tape_player (
        .clk(clk),
        .resetn(resetn),
        .start(tape_start),
        .tape_length(tape_length),
        .tape_read_data(tape_data),
        .tape_read_address(tape_address),
        .tape_in(tape_in),
        .busy(tape_busy),
        .done(tape_done)
    );

endmodule

`default_nettype wire
