// SPDX-License-Identifier: GPL-3.0-only
// ZX81 cassette waveform player for raw .P program files.
// The .P payload starts at 0x4009 and omits the cassette filename; currently
// emit 0x80 as a proposed empty-filename terminator, then the payload, through
// the normal EAR input path. This convention still needs validation against
// the ZX81 ROM/hardware. Playback starts only when the machine enters LOAD.
//
// Nominal original-speed timing at the 52 MHz ZX81 machine clock:
//   5 s leader, 150 us high + 150 us low per pulse, 4 pulses for 0,
//   9 pulses for 1, then 1.3 ms inter-bit silence. This gives approximately
//   300 bit/s for typical data; there is deliberately no turbo mode.
`default_nettype none

module zx81_tape_player #(
    parameter integer PULSE_HALF_CYCLES = 7800,
    parameter integer BIT_GAP_CYCLES    = 67600,
    parameter integer LEADER_CYCLES     = 260000000,
    parameter integer READ_LATENCY       = 1
) (
    input  wire logic        clk,
    input  wire logic        resetn,
    input  wire logic        start,
    input  wire logic [14:0] tape_length,
    input  wire logic [7:0]  tape_read_data,
    output logic [13:0] tape_read_address,
    output logic        tape_in,
    output logic        busy,
    output logic        done
);

    localparam [3:0] ST_IDLE      = 4'd0;
    localparam [3:0] ST_LEADER    = 4'd1;
    localparam [3:0] ST_READ      = 4'd2;
    localparam [3:0] ST_BIT_START = 4'd3;
    localparam [3:0] ST_PULSE_HI  = 4'd4;
    localparam [3:0] ST_PULSE_LO  = 4'd5;
    localparam [3:0] ST_BIT_GAP   = 4'd6;
    localparam [3:0] ST_DONE      = 4'd7;

    logic [3:0] state;
    logic [27:0] timer;
    logic [14:0] byte_index;       // 0 is the synthesized empty filename
    logic [7:0]  current_byte;
    logic [2:0]  bit_index;
    logic [3:0]  pulses_left;
    logic [7:0]  read_wait;

    // The first byte is a zero-length name (bit 7 marks its final character).
    // Subsequent bytes come from the synchronous tape buffer at address n - 1.
    always_comb begin
        if (byte_index == 0)
            tape_read_address = 14'd0;
        else
            tape_read_address = byte_index[13:0] - 1'b1;
    end

    always_ff @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            state        <= ST_IDLE;
            timer        <= 28'd0;
            byte_index   <= 15'd0;
            current_byte <= 8'd0;
            bit_index    <= 3'd7;
            pulses_left <= 4'd0;
            read_wait    <= 8'd0;
            tape_in      <= 1'b0;
            busy         <= 1'b0;
            done         <= 1'b0;
        end else begin
            done <= 1'b0;

            if (start && state == ST_IDLE) begin
                if (tape_length != 0) begin
                    state        <= ST_LEADER;
                    timer        <= 28'(LEADER_CYCLES - 1);
                    byte_index   <= 15'd0;
                    current_byte <= 8'h80;
                    bit_index    <= 3'd7;
                    tape_in      <= 1'b0;
                    busy         <= 1'b1;
                end else begin
                    done <= 1'b1;
                end
            end else begin
                case (state)
                    ST_IDLE: begin
                        tape_in <= 1'b0;
                        busy    <= 1'b0;
                    end

                    ST_LEADER: begin
                        tape_in <= 1'b0;
                        if (timer == 0)
                            state <= ST_BIT_START;
                        else
                            timer <= timer - 1'b1;
                    end

                    ST_READ: begin
                        if (read_wait != 0)
                            read_wait <= read_wait - 1'b1;
                        else begin
                            current_byte <= tape_read_data;
                            bit_index    <= 3'd7;
                            state        <= ST_BIT_START;
                        end
                    end

                    ST_BIT_START: begin
                        pulses_left <= current_byte[bit_index] ? 4'd9 : 4'd4;
                        timer       <= 28'(PULSE_HALF_CYCLES - 1);
                        tape_in     <= 1'b1;
                        state       <= ST_PULSE_HI;
                    end

                    ST_PULSE_HI: begin
                        if (timer == 0) begin
                            timer   <= 28'(PULSE_HALF_CYCLES - 1);
                            tape_in <= 1'b0;
                            state   <= ST_PULSE_LO;
                        end else
                            timer <= timer - 1'b1;
                    end

                    ST_PULSE_LO: begin
                        if (timer == 0) begin
                            if (pulses_left > 1) begin
                                pulses_left <= pulses_left - 1'b1;
                                timer       <= 28'(PULSE_HALF_CYCLES - 1);
                                tape_in     <= 1'b1;
                                state       <= ST_PULSE_HI;
                            end else begin
                                timer   <= 28'(BIT_GAP_CYCLES - 1);
                                tape_in <= 1'b0;
                                state   <= ST_BIT_GAP;
                            end
                        end else
                            timer <= timer - 1'b1;
                    end

                    ST_BIT_GAP: begin
                        tape_in <= 1'b0;
                        if (timer == 0) begin
                            if (bit_index != 0) begin
                                bit_index <= bit_index - 1'b1;
                                state     <= ST_BIT_START;
                            end else if (byte_index == tape_length) begin
                                state <= ST_DONE;
                            end else begin
                                byte_index <= byte_index + 1'b1;
                                read_wait  <= 8'(READ_LATENCY);
                                state      <= ST_READ;
                            end
                        end else
                            timer <= timer - 1'b1;
                    end

                    ST_DONE: begin
                        tape_in <= 1'b0;
                        busy    <= 1'b0;
                        done    <= 1'b1;
                        state   <= ST_IDLE;
                    end

                    default: begin
                        state   <= ST_IDLE;
                        tape_in <= 1'b0;
                        busy    <= 1'b0;
                    end
                endcase
            end
        end
    end

endmodule

`default_nettype wire
