// SPDX-License-Identifier: GPL-3.0-only
// TangZX81 USB/BL616 scancode-to-key-matrix mapper.
// Input bytes are PS/2 Set-2 scancodes produced by firmware command 0x0c.
// Key state is active-high internally and returned active-low, as read by the
// ZX81 ULA. This implementation is authored for TangZX81; it does not import
// the upstream MiSTer keyboard module (which has a non-commercial-only term).
`default_nettype none

module zx81_keyboard_matrix (
    input  logic        clk,
    input  logic        resetn,
    input  logic [7:0]  kbd_data,
    input  logic        kbd_data_valid,
    input  logic [15:0] addr,
    // TangCore DS2/SNES layout: R,L,X,A,RIGHT,LEFT,DOWN,UP,START,SELECT,Y,B.
    input  logic [11:0] joy,
    output logic [4:0]  key_data
);

    // Row-major ZX81 matrix, five active-low columns per row:
    //   0 SHIFT Z X C V      4 0 9 8 7 6
    //   1 A S D F G          5 P O I U Y
    //   2 Q W E R T          6 ENTER L K J H
    //   3 1 2 3 4 5          7 SPACE SYMBOL M N B
    logic [39:0] keys_down;
    logic shift_left;
    logic shift_right;
    logic symbol_shift;
    logic caps_lock_key;
    logic extended_prefix;
    logic break_prefix;
    logic arrow_up;
    logic arrow_down;
    logic arrow_left;
    logic arrow_right;
    logic backspace_key;
    logic escape_key;
    logic [39:0] effective_keys;

    always_ff @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            keys_down       <= 40'd0;
            shift_left      <= 1'b0;
            shift_right     <= 1'b0;
            symbol_shift    <= 1'b0;
            caps_lock_key   <= 1'b0;
            extended_prefix <= 1'b0;
            break_prefix    <= 1'b0;
            arrow_up        <= 1'b0;
            arrow_down      <= 1'b0;
            arrow_left      <= 1'b0;
            arrow_right     <= 1'b0;
            backspace_key   <= 1'b0;
            escape_key      <= 1'b0;
        end else if (kbd_data_valid) begin
            if (kbd_data == 8'hE0) begin
                extended_prefix <= 1'b1;
            end else if (kbd_data == 8'hF0) begin
                break_prefix <= 1'b1;
            end else begin
                if (extended_prefix) begin
                    case (kbd_data)
                        8'h75: arrow_up    <= ~break_prefix;
                        8'h72: arrow_down  <= ~break_prefix;
                        8'h6B: arrow_left  <= ~break_prefix;
                        8'h74: arrow_right <= ~break_prefix;
                        8'h14: symbol_shift <= ~break_prefix; // right Ctrl
                        8'h71: backspace_key <= ~break_prefix; // Delete
                        default: ;
                    endcase
                end else begin
                    case (kbd_data)
                        8'h12: shift_left    <= ~break_prefix;
                        8'h59: shift_right   <= ~break_prefix;
                        8'h14: symbol_shift  <= ~break_prefix; // left Ctrl
                        8'h58: caps_lock_key <= ~break_prefix;
                        8'h66: backspace_key <= ~break_prefix;
                        8'h76: escape_key    <= ~break_prefix;

                        // ZX81 letters, mapped from the standard PS/2 Set-2 set.
                        8'h1A: keys_down[1]  <= ~break_prefix; // Z
                        8'h22: keys_down[2]  <= ~break_prefix; // X
                        8'h21: keys_down[3]  <= ~break_prefix; // C
                        8'h2A: keys_down[4]  <= ~break_prefix; // V
                        8'h1C: keys_down[5]  <= ~break_prefix; // A
                        8'h1B: keys_down[6]  <= ~break_prefix; // S
                        8'h23: keys_down[7]  <= ~break_prefix; // D
                        8'h2B: keys_down[8]  <= ~break_prefix; // F
                        8'h34: keys_down[9]  <= ~break_prefix; // G
                        8'h15: keys_down[10] <= ~break_prefix; // Q
                        8'h1D: keys_down[11] <= ~break_prefix; // W
                        8'h24: keys_down[12] <= ~break_prefix; // E
                        8'h2D: keys_down[13] <= ~break_prefix; // R
                        8'h2C: keys_down[14] <= ~break_prefix; // T
                        8'h16: keys_down[15] <= ~break_prefix; // 1
                        8'h1E: keys_down[16] <= ~break_prefix; // 2
                        8'h26: keys_down[17] <= ~break_prefix; // 3
                        8'h25: keys_down[18] <= ~break_prefix; // 4
                        8'h2E: keys_down[19] <= ~break_prefix; // 5
                        8'h45: keys_down[20] <= ~break_prefix; // 0
                        8'h46: keys_down[21] <= ~break_prefix; // 9
                        8'h3E: keys_down[22] <= ~break_prefix; // 8
                        8'h3D: keys_down[23] <= ~break_prefix; // 7
                        8'h36: keys_down[24] <= ~break_prefix; // 6
                        8'h4D: keys_down[25] <= ~break_prefix; // P
                        8'h44: keys_down[26] <= ~break_prefix; // O
                        8'h43: keys_down[27] <= ~break_prefix; // I
                        8'h3C: keys_down[28] <= ~break_prefix; // U
                        8'h35: keys_down[29] <= ~break_prefix; // Y
                        8'h5A: keys_down[30] <= ~break_prefix; // ENTER
                        8'h4B: keys_down[31] <= ~break_prefix; // L
                        8'h42: keys_down[32] <= ~break_prefix; // K
                        8'h3B: keys_down[33] <= ~break_prefix; // J
                        8'h33: keys_down[34] <= ~break_prefix; // H
                        8'h29: keys_down[35] <= ~break_prefix; // SPACE
                        8'h3A: keys_down[37] <= ~break_prefix; // M
                        8'h31: keys_down[38] <= ~break_prefix; // N
                        8'h32: keys_down[39] <= ~break_prefix; // B
                        default: ;
                    endcase
                end

                extended_prefix <= 1'b0;
                break_prefix    <= 1'b0;
            end
        end
    end

    always_comb begin
        effective_keys = keys_down;

        // Host Shift/Caps maps to ZX81 CAPS SHIFT; Ctrl maps to SYMBOL SHIFT.
        effective_keys[0]  = keys_down[0] | shift_left | shift_right | caps_lock_key |
                             escape_key | backspace_key | arrow_up | arrow_down |
                             arrow_left | arrow_right | joy[4] | joy[5] | joy[6] | joy[7];
        effective_keys[36] = keys_down[36] | symbol_shift;

        // Cursor keys use CAPS SHIFT + 5/6/7/8. The TangCore pad stores
        // RIGHT, LEFT, DOWN, UP in bits 4, 5, 6, 7 respectively.
        effective_keys[19] = keys_down[19] | arrow_left | joy[5];  // 5 = left
        effective_keys[24] = keys_down[24] | arrow_down | joy[6];  // 6 = down
        effective_keys[23] = keys_down[23] | arrow_up | joy[7];    // 7 = up
        effective_keys[22] = keys_down[22] | arrow_right | joy[4]; // 8 = right

        // Backspace is CAPS SHIFT + 0; Escape is CAPS SHIFT + SPACE.
        effective_keys[20] = keys_down[20] | backspace_key;
        effective_keys[35] = keys_down[35] | escape_key;

        // A/B/START are convenient ENTER keys for controllers.
        effective_keys[30] = keys_down[30] | joy[3] | joy[8] | joy[11];
    end

    always_comb begin
        key_data = 5'b11111;
        for (int row = 0; row < 8; row++) begin
            if (!addr[8 + row]) begin
                for (int column = 0; column < 5; column++) begin
                    if (effective_keys[(row * 5) + column])
                        key_data[column] = 1'b0;
                end
            end
        end
    end

endmodule

`default_nettype wire
