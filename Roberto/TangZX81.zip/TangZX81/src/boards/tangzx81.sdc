// TangZX81 timing constraints for Tang Console 138K.
// PLL output clocks are constrained as roots; clk_pixel is a /5 generated clock.

create_clock -name sys_clk -period 20.000 [get_nets {sys_clk}]
create_clock -name clk12 -period 83.333 [get_nets {clk12}]
create_clock -name clk_core -period 19.230769 [get_nets {clk_core}]
create_clock -name clk27 -period 37.037 [get_nets {clk27}]
create_clock -name clk5x -period 2.693603 [get_nets {clk5x}]
create_generated_clock -name clk_pixel -source [get_nets {clk5x}] -divide_by 5 [get_nets {clk_pixel}]
