// SPDX-License-Identifier: GPL-3.0-only
// TangZX81 top level for Tang Console 138K (GW5AST-LV138PG484AC1/I0).
`timescale 1ns / 1ps
`default_nettype none

module zx81_tang_top (
    input  logic sys_clk,
    input  logic s1,                 // active-low machine reset button
    input  logic UART_RXD,
    output logic UART_TXD,

    // SDRAM is unused: ZX81 RAM is internal block RAM.
    output logic O_sdram_clk,
    output logic O_sdram_cs_n,
    output logic O_sdram_cas_n,
    output logic O_sdram_ras_n,
    output logic O_sdram_wen_n,
    inout  wire [15:0] IO_sdram_dq,
    output logic [12:0] O_sdram_addr,
    output logic [1:0] O_sdram_ba,
    output logic [1:0] O_sdram_dqm,

    output logic [7:0] led,

    // DualShock 2 x2 on PMOD1.
    output logic ds_clk,
    input  logic ds_miso,
    output logic ds_mosi,
    output logic ds_cs,
    output logic ds_clk2,
    input  logic ds_miso2,
    output logic ds_mosi2,
    output logic ds_cs2,

    // USB HID x2 on the FPGA USB-A connectors.
    inout wire usb1_dp,
    inout wire usb1_dn,
    inout wire usb2_dp,
    inout wire usb2_dn,

    // HDMI transmitter.
    output logic tmds_clk_n,
    output logic tmds_clk_p,
    output logic [2:0] tmds_d_n,
    output logic [2:0] tmds_d_p
`ifdef VERILATOR
    ,input  logic        sim_clk_main,
    input  logic        sim_clk_core,
    input  logic        sim_clk12,
    input  logic        sim_clk_pixel,
    input  logic        sim_clk_5x_pixel,
    input  logic        sim_resetn,
    input  logic [11:0] sim_joy_usb1,
    input  logic [11:0] sim_joy_usb2,
    input  logic [15:0] sim_hid1,
    input  logic [15:0] sim_hid2,
    input  logic        sim_overlay,
    input  logic [14:0] sim_overlay_color,
    input  logic [31:0] sim_core_config,
    input  logic [7:0]  sim_loading_state,
    input  logic [7:0]  sim_data,
    input  logic        sim_data_valid,
    input  logic [7:0]  sim_kbd_data,
    input  logic        sim_kbd_valid,
    output logic [23:0] sim_rgb,
    output logic [10:0] sim_cx,
    output logic [9:0]  sim_cy,
    output logic        sim_active,
    output logic        sim_core_resetn,
    output logic        sim_tape_busy
`endif
);

    wire clk_main;
    wire clk_core;
    wire clk12;
    wire clk27;
    wire clk5x;
    wire clk_pixel;
    wire pll_lock_12;
    wire pll_lock_core;
    logic sys_resetn;
    wire pll_locks = pll_lock_12 & pll_lock_core;

`ifndef VERILATOR
    assign clk_main = sys_clk;
    pll_12_14m pll_sys (.lock(pll_lock_12), .clkout0(clk12), .clkout1(), .clkin(sys_clk));
    gowin_pll_52 pll_core (.lock(pll_lock_core), .clkout0(clk_core), .clkout1(), .clkin(sys_clk));
    gowin_pll_27 pll_27 (.clkin(sys_clk), .clkout0(clk27));
    gowin_pll_hdmi pll_hdmi (.clkin(clk27), .clkout(clk5x));
    CLKDIV #(.DIV_MODE(5)) div5 (
        .CLKOUT(clk_pixel), .HCLKIN(clk5x), .RESETN(sys_resetn), .CALIB(1'b0)
    );

    logic [7:0] reset_count;
    always_ff @(posedge clk_main or negedge pll_locks) begin
        if (!pll_locks) begin
            reset_count <= 8'd0;
            sys_resetn <= 1'b0;
        end else if (reset_count != 8'hFF) begin
            reset_count <= reset_count + 1'b1;
            sys_resetn <= 1'b0;
        end else begin
            sys_resetn <= 1'b1;
        end
    end
`else
    assign clk_main = sim_clk_main;
    assign clk_core = sim_clk_core;
    assign clk12 = sim_clk12;
    assign clk27 = 1'b0;
    assign clk5x = sim_clk_5x_pixel;
    assign clk_pixel = sim_clk_pixel;
    assign pll_lock_12 = 1'b1;
    assign pll_lock_core = 1'b1;
    always_comb sys_resetn = sim_resetn;
`endif

    wire [11:0] ds1;
    wire [11:0] ds2;
    wire [11:0] usb1_raw;
    wire [11:0] usb2_raw;
    logic [11:0] usb1_sync;
    logic [11:0] usb2_sync;
    wire [15:0] hid1;
    wire [15:0] hid2;
    wire [11:0] joy1 = ds1 | usb1_sync | hid1[11:0];
    wire [11:0] joy2 = ds2 | usb2_sync | hid2[11:0];

`ifndef VERILATOR
    controller_ds2 #(.FREQ(50_000_000)) ds2_p1 (
        .clk(clk_main), .snes_buttons(ds1),
        .ds_clk(ds_clk), .ds_miso(ds_miso), .ds_mosi(ds_mosi), .ds_cs(ds_cs)
    );
    controller_ds2 #(.FREQ(50_000_000)) ds2_p2 (
        .clk(clk_main), .snes_buttons(ds2),
        .ds_clk(ds_clk2), .ds_miso(ds_miso2), .ds_mosi(ds_mosi2), .ds_cs(ds_cs2)
    );

    wire [1:0] usb_type1;
    wire [1:0] usb_type2;
    wire usb_conerr1;
    wire usb_conerr2;
    usb_hid_host usb_hid1 (
        .usbclk(clk12), .usbrst_n(pll_lock_12),
        .usb_dm(usb1_dn), .usb_dp(usb1_dp),
        .game_snes(usb1_raw), .typ(usb_type1), .conerr(usb_conerr1)
    );
    usb_hid_host usb_hid2 (
        .usbclk(clk12), .usbrst_n(pll_lock_12),
        .usb_dm(usb2_dn), .usb_dp(usb2_dp),
        .game_snes(usb2_raw), .typ(usb_type2), .conerr(usb_conerr2)
    );
`else
    assign {ds1, ds2} = 24'd0;
    assign usb1_raw = sim_joy_usb1;
    assign usb2_raw = sim_joy_usb2;
    assign {ds_clk, ds_mosi, ds_cs, ds_clk2, ds_mosi2, ds_cs2} = 6'b0;
    assign usb1_dp = 1'bz;
    assign usb1_dn = 1'bz;
    assign usb2_dp = 1'bz;
    assign usb2_dn = 1'bz;
    wire [1:0] usb_type1 = 2'b00;
    wire [1:0] usb_type2 = 2'b00;
    wire usb_conerr1 = 1'b0;
    wire usb_conerr2 = 1'b0;
`endif

    genvar joy_bit;
    generate for (joy_bit = 0; joy_bit < 12; joy_bit = joy_bit + 1) begin : sync_usb
        logic usb1_meta;
        logic usb2_meta;
        always_ff @(posedge clk_main or negedge sys_resetn) begin
            if (!sys_resetn) begin
                usb1_meta <= 1'b0;
                usb1_sync[joy_bit] <= 1'b0;
                usb2_meta <= 1'b0;
                usb2_sync[joy_bit] <= 1'b0;
            end else begin
                usb1_meta <= usb1_raw[joy_bit];
                usb1_sync[joy_bit] <= usb1_meta;
                usb2_meta <= usb2_raw[joy_bit];
                usb2_sync[joy_bit] <= usb2_meta;
            end
        end
    end endgenerate

    wire overlay;
    wire [7:0] overlay_x;
    wire [7:0] overlay_y;
    wire [14:0] overlay_color;
    wire [7:0] rom_loading;
    wire [7:0] rom_do;
    wire rom_do_valid;
    wire [31:0] core_config;
    wire [7:0] kbd_data;
    wire kbd_data_valid;

`ifndef VERILATOR
    iosys_bl616 #(.COLOR_LOGO(15'h7FFF), .FREQ(50_000_000), .CORE_ID(8)) iosys (
        .clk(clk_main), .hclk(clk_pixel), .resetn(sys_resetn),
        .overlay(overlay), .overlay_x(overlay_x), .overlay_y(overlay_y),
        .overlay_color(overlay_color),
        .joy1(ds1 | usb1_sync), .joy2(ds2 | usb2_sync),
        .hid1(hid1), .hid2(hid2),
        .rom_loading(rom_loading), .rom_do(rom_do), .rom_do_valid(rom_do_valid),
        .mgmt_address(), .mgmt_read(), .mgmt_readdata(16'd0),
        .mgmt_write(), .mgmt_writedata(), .fdd_request(2'b00),
        .kbd_data(kbd_data), .kbd_data_valid(kbd_data_valid),
        .core_config(core_config),
        .uart_rx(UART_RXD), .uart_tx(UART_TXD)
    );
`else
    assign overlay = sim_overlay;
    assign overlay_color = sim_overlay_color;
    assign hid1 = sim_hid1;
    assign hid2 = sim_hid2;
    assign rom_loading = sim_loading_state;
    assign rom_do = sim_data;
    assign rom_do_valid = sim_data_valid;
    assign core_config = sim_core_config;
    assign kbd_data = sim_kbd_data;
    assign kbd_data_valid = sim_kbd_valid;
    assign UART_TXD = 1'b1;
`endif

    wire [7:0] rom_buffer_data;
    wire [12:0] rom_buffer_address;
    wire [7:0] tape_buffer_data;
    wire [13:0] tape_buffer_address;
    wire rom_ready;
    wire tape_ready;
    wire [14:0] tape_length;
    wire stream_overflow;
    zx81_sd_loader loader (
        .clk_write(clk_main),
        .clk_core(clk_core),
        .resetn(sys_resetn),
        .loading_state(rom_loading),
        .data_in(rom_do),
        .data_valid(rom_do_valid),
        .rom_read_address(rom_buffer_address),
        .rom_read_data(rom_buffer_data),
        .tape_read_address(tape_buffer_address),
        .tape_read_data(tape_buffer_data),
        .rom_ready(rom_ready),
        .tape_ready(tape_ready),
        .tape_length(tape_length),
        .overflow(stream_overflow)
    );

    logic loading_meta;
    logic loading_core;
    logic s1_meta;
    logic s1_core;
    always_ff @(posedge clk_core or negedge sys_resetn) begin
        if (!sys_resetn) begin
            loading_meta <= 1'b1;
            loading_core <= 1'b1;
            s1_meta <= 1'b1;
            s1_core <= 1'b1;
        end else begin
            loading_meta <= (rom_loading != 8'd0);
            loading_core <= loading_meta;
            s1_meta <= s1;
            s1_core <= s1_meta;
        end
    end

    // The ZX81 boots from its supplied ROM even when no tape is selected.
    // Tape playback remains inhibited in zx81_machine until tape_ready is set.
    wire machine_resetn = sys_resetn & rom_ready & ~loading_core & s1_core;
`ifdef VERILATOR
    assign sim_core_resetn = machine_resetn;
`endif

    wire ce_pixel;
    wire hblank;
    wire vblank;
    wire video_pixel;
    wire tape_busy;
    wire tape_done;

    zx81_machine machine (
        .clk(clk_core),
        .resetn(machine_resetn),
        .joy(joy1),
        .core_config(core_config),
        .kbd_data(kbd_data),
        .kbd_data_valid(kbd_data_valid),
        .rom_data(rom_buffer_data),
        .rom_address(rom_buffer_address),
        .tape_data(tape_buffer_data),
        .tape_address(tape_buffer_address),
        .tape_length(tape_length),
        .tape_ready(tape_ready),
        .tape_busy(tape_busy),
        .tape_done(tape_done),
        .ce_pixel(ce_pixel),
        .hblank(hblank),
        .vblank(vblank),
        .video_pixel(video_pixel)
    );

    zx81_video_hdmi video (
        .clk_core(clk_core),
        .resetn(sys_resetn),
        .ce_pixel(ce_pixel),
        .hblank(hblank),
        .vblank(vblank),
        .video_pixel(video_pixel),
        .overlay(overlay),
        .overlay_color(overlay_color),
        .overlay_x(overlay_x),
        .overlay_y(overlay_y),
        .clk_pixel(clk_pixel),
        .clk_5x_pixel(clk5x),
        .tmds_clk_n(tmds_clk_n),
        .tmds_clk_p(tmds_clk_p),
        .tmds_d_n(tmds_d_n),
        .tmds_d_p(tmds_d_p)
`ifdef VERILATOR
        ,.sim_rgb(sim_rgb), .sim_cx(sim_cx), .sim_cy(sim_cy), .sim_active(sim_active)
`endif
    );

    // The user reset button restarts the CPU without discarding SD buffers.
    logic [22:0] heartbeat;
    always_ff @(posedge clk_core or negedge sys_resetn) begin
        if (!sys_resetn)
            heartbeat <= 23'd0;
        else
            heartbeat <= heartbeat + 1'b1;
    end

    assign led = {stream_overflow, tape_busy, tape_ready, rom_ready,
                  usb_conerr1, usb_conerr2,
                  heartbeat[22], heartbeat[21]};

    assign O_sdram_clk = 1'b0;
    assign O_sdram_cs_n = 1'b1;
    assign O_sdram_ras_n = 1'b1;
    assign O_sdram_cas_n = 1'b1;
    assign O_sdram_wen_n = 1'b1;
    assign O_sdram_addr = 13'b0;
    assign O_sdram_ba = 2'b0;
    assign O_sdram_dqm = 2'b11;
    assign IO_sdram_dq = 16'bz;

endmodule

`default_nettype wire
